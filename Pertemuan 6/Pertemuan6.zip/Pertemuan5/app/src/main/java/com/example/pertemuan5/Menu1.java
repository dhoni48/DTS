package com.example.pertemuan5;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {
    Button BtnOK, BtnChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        BtnOK = findViewById(R.id.Btn1);
        BtnChange = findViewById(R.id.Btn2);

        BtnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BtnOK.setBackgroundColor(Color.RED);
            }
        });

        BtnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BtnChange.setBackgroundColor(Color.GREEN);
            }
        });
    }
}
