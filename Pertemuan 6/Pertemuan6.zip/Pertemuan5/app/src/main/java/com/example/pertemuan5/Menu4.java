package com.example.pertemuan5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    EditText Txt_Angka;
    TextView Hasil_Akar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        Txt_Angka = findViewById(R.id.Txt_Angka);
        Hasil_Akar = findViewById(R.id.Hitung_Tampil);
    }

    public void Hitung_Akar(View v){
        String hasil = Txt_Angka.getText().toString();
        int akar = Integer.parseInt(hasil);

        int x=1;
        int y=x*x;

        while(y != akar){
            x++;
            y=x*x;
        }
        Hasil_Akar.setText("Akar dari " + hasil + " adalah " + x);
    }
}
