package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {
    EditText Txt_Nama;
    TextView Lbl_Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);

        Txt_Nama = findViewById(R.id.etName);
        Lbl_Hasil = findViewById(R.id.tvTampil);
    }

    public void Tampil_Hasil(View v){
        Lbl_Hasil.setText("Nama anda adalah : \n" + Txt_Nama.getText());
    }
}
